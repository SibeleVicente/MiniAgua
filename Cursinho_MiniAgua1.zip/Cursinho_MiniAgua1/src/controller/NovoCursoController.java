package controller;

import java.sql.SQLException;
import model.NovoCurso;
import model.NovoCursoDAO;

public class NovoCursoController {
	public void InserirCurso(String id, String nome, String turno) throws SQLException {
		NovoCurso nc = new NovoCurso();
		nc.setId(id);
		nc.setNome(nome);
		nc.setTurno(turno);
		new NovoCursoDAO().Inserir(nc);
	}
}
