package controller;

import java.sql.SQLException;
import model.NovoAluno;
import model.NovoAlunoDAO;

/*
 * @author Sibele
 */
public class NovoAlunoController {
    public void InserirAluno(String matricula, String turma, String nomeA, String nomeR, String cpf, String tel, String sx, String curso, String turno ) throws SQLException {
		NovoAluno na = new NovoAluno();
		na.setMatricula(matricula);
		na.setTurma(turma);
                na.setNomeA(nomeA);
                na.setNomeR(nomeR);
                na.setCPF(cpf);
                na.setTel(tel);
                na.setSexo(sx);
                na.setCurso(curso);
		na.setTurno(turno);
		new NovoAlunoDAO().Inserir(na);
	}
}


