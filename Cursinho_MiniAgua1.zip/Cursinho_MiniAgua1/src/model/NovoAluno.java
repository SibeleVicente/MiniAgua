package model;
/*
 * @author Sibele
 */
public class NovoAluno {
    private String Matricula;
    private String Turma;
    private String NomeA;
    private String NomeR;
    private String DTnasc;
    private String CPF;
    private String Tel;
    private String Sexo;
    private String Curso;
    private String Turno;

    public String getMatricula() {
        return Matricula;
    }

    public void setMatricula(String matricula) {
        Matricula = matricula;
    }

    public String getTurma() {
        return Turma;
    }

    public void setTurma(String turma) {
        Turma = turma;
    }

    public String getNomeA() {
        return NomeA;
    }

    public void setNomeA(String nomeA) {
        NomeA = nomeA;
    }

    public String getNomeR() {
        return NomeR;
    }

    public void setNomeR(String nomeR) {
        NomeR = nomeR;
    }

    public String getDTnasc() {
        return DTnasc;
    }

    public void setDTnasc(String dt_nasc) {
        DTnasc = dt_nasc;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String cpf) {
        CPF = cpf;
    }

    public String getTel() {
        return Tel;
    }

    public void setTel(String tel) {
        Tel = tel;
    }

    public String getSexo() {
        return Sexo;
    }

    public void setSexo(String sx) {
        Sexo = sx;
    }

    public String getCurso() {
        return Curso;
    }

    public void setCurso(String curso) {
        Curso = curso;
    }

    public String getTurno() {
        return Turno;
    }

    public void setTurno(String turno) {
        Turno = turno;
    }
    
    
      
}
