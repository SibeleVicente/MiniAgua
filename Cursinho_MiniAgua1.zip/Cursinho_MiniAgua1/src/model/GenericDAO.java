package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import infra.conexao;

public abstract class GenericDAO {
	private Connection conn;	//declara um objeto Connection
	
	protected GenericDAO() {	//construtor
		this.conn = conexao.getConnection();	//pega a conexao
	}
	
	protected Connection getConnection() {	//metodo que retorna a conexao
		return conn;
	}
	
	protected void inserir(String sql, Object...parametros) throws SQLException { //metodo para inserir no banco
		PreparedStatement stmt = getConnection().prepareStatement(sql); //Prepara a instru��o sql passada por parametro
		for(int i=0; i<parametros.length; i++) {	//enquanto n�o percorrer todos os parametros ele ira continuar
			stmt.setObject(i+1, parametros[i]);	//seta os objetos de acordo com os parametros passados
		}
                
               //stmt.setObject(parametros.length-1,parametros[0]);
                stmt.execute();
		stmt.close();
	}
	
	protected void atualizar(String sql, Object ID, Object...parametros) throws SQLException {		//metodo para atualizar os dados
		PreparedStatement stmt = getConnection().prepareStatement(sql);		//prepara a String sql passada
		for(int i=0; i<parametros.length; i++) {
			stmt.setObject(1+1, parametros[i]);		//seta os parametros pulando o ID
		}
		stmt.setObject(parametros.length+1, ID);	//seta s� o ID
		stmt.execute();
		stmt.close();
	}
	
	protected void excluir(String sql, Object ID) throws SQLException {		//metodo de excluir
		PreparedStatement stmt= getConnection().prepareStatement(sql);	//Prepara a String
		stmt.setObject(0, ID);
		stmt.execute();
		stmt.close();
	}
}
