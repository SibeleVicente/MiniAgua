package model;

import java.sql.SQLException;

/*
 * @author Sibele
 */
public class NovoAlunoDAO  extends GenericDAO{
	public void Inserir(NovoAluno na) throws SQLException {
		 String sql = "INSERT INTO ALUNO(MATRICULA,TURMA,NOMEA,NOMER,DTNASC,CPF,TEL,SEXO,CURSO,TURNO) VALUES(?,?,?,?,?,?,?,?,?,?)";
		inserir(sql, Integer.parseInt(na.getMatricula()), na.getTurma(), na.getNomeA(),na.getNomeR(),na.getDTnasc(),na.getCPF(),na.getTel(),na.getSexo(),na.getCurso(), na.getTurno());	//chama o metodo do genericDAO e passa a string e parametros
	}
	public void Atualizar(NovoAluno na) throws SQLException {
		String sql = "";
		atualizar(sql,  na.getMatricula(), na.getTurma(), na.getNomeA(),na.getNomeR(),na.getDTnasc(),na.getCPF(),na.getTel(),na.getSexo(),na.getCurso(), na.getTurno());	//chama o metodo do genericDAO e passa a string e parametros
	}
	public void Excluir(NovoAluno na) throws SQLException {
		String sql = "DELETE FROM ALUNO WHERE MATRICULA=?";
		excluir(sql, na.getMatricula());	//chama o metodo do genericDAO e passa a string e parametros
	}
}
