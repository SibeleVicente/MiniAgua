package model;

import java.sql.SQLException;

public class NovoCursoDAO extends GenericDAO{
	public void Inserir(NovoCurso nc) throws SQLException {
		String sql = "INSERT INTO CURSO(ID,NOME,TURNO) VALUES(?,?,?)";
		inserir(sql, Integer.parseInt(nc.getId()), nc.getNome(), nc.getTurno());	//chama o metodo do genericDAO e passa a string e parametros
	}
	public void Atualizar(NovoCurso nc) throws SQLException {
		String sql = "";
		atualizar(sql, nc.getId(), nc.getNome(), nc.getTurno());	//chama o metodo do genericDAO e passa a string e parametros
	}
	public void Excluir(NovoCurso nc) throws SQLException {
		String sql = "DELETE FROM CURSO WHERE ID=?";
		excluir(sql, nc.getId());	//chama o metodo do genericDAO e passa a string e parametros
	}
}
