package cursinho_miniagua;

/*
 * Sibele Vicente
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/*Tela do novo professor*/
public class NovoProfessor_MiniAgua {

    JFrame telinha4 = new JFrame();
    JPanel vazio1 = new JPanel();
    JPanel cadastroP = new JPanel();
    JPanel vazio2 = new JPanel();
    JPanel vazio3 = new JPanel();
    JLabel vz1 = new JLabel(" ");
    JLabel vz2 = new JLabel(" ");
    JLabel vz3 = new JLabel(" ");
    JLabel vz4 = new JLabel(" ");
    JLabel titulo = new JLabel("Cadastro de Professor");
    JLabel nomeP = new JLabel("Nome Completo");
    JTextField txtNome = new JTextField(44);
    JLabel dtNascP = new JLabel("Data de Nasc.");
    JTextField txtNascP = new JTextField(" ##/##/#### ");
    JLabel CPFp = new JLabel("CPF");
    JTextField txtCPFp = new JTextField(15);
    JLabel RGp = new JLabel("RG");
    JTextField txtRG = new JTextField(9);
    JLabel Tel = new JLabel("Telefone");
    JTextField txtTel = new JTextField(15);
    JLabel ID = new JLabel("ID");
    JTextField txtID = new JTextField(10);
    JLabel sexo = new JLabel("Sexo");
    JComboBox CBsexo = new JComboBox();
    JLabel cursoP = new JLabel("Curso");
    JComboBox CBcursoP = new JComboBox();
    JButton save = new JButton("Salvar");

    public NovoProfessor_MiniAgua() {

        telinha4.setTitle("Novo Professor");
        telinha4.setSize(600, 450);
        telinha4.setLayout(new GridLayout(4, 1));
        telinha4.setResizable(false);
        telinha4.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        telinha4.setLocationRelativeTo(null);
        telinha4.setVisible(true);
        telinha4.add(vazio1);
        telinha4.add(cadastroP);
        telinha4.add(vazio2);
        telinha4.add(vazio3);
        vazio1.add(titulo);
        titulo.setFont(new Font("Times New Roman", 20, 20));

        cadastroP.add(nomeP);
        cadastroP.add(txtNome);
        cadastroP.add(Tel);
        cadastroP.add(txtTel);
        cadastroP.add(dtNascP);
        cadastroP.add(txtNascP);
        //cadastroP.add(vz1);
        //cadastroP.add(vz1);
        cadastroP.add(CPFp);
        cadastroP.add(txtCPFp);
        cadastroP.add(RGp);
        cadastroP.add(txtRG);
        //cadastroP.add(vz2);
        //cadastroP.add(vz2);

        cadastroP.add(ID);
        cadastroP.add(txtID);
        //cadastroP.add(vz2);
        //cadastroP.add(vz2);
        cadastroP.add(sexo);
        cadastroP.add(CBsexo);
        CBsexo.addItem("            ");
        CBsexo.addItem("Feminino");
        CBsexo.addItem("Masculino");
        cadastroP.add(cursoP);
        cadastroP.add(CBcursoP);
        CBcursoP.addItem("               ");
         
        /*As opções seram adicionadas após a criação do BD*/
        vazio3.add(save);
            Boxinho(); 
        class AcaoSaveBt implements ActionListener {

            public void actionPerformed(ActionEvent newIc) {
                CadastraProf();
            }
        }
        AcaoSaveBt ASB = new AcaoSaveBt();
        save.addActionListener(ASB);
    }

    public void CadastraProf() {

        String ArNome = txtNome.getText();
        String ArdataNasc = txtNascP.getText();
        String ArTell = txtTel.getText();
        String ArSx = (String) CBsexo.getSelectedItem();
        String ArCurso = (String) CBcursoP.getSelectedItem();
        String ArRG = txtRG.getText();
        String ArID = txtID.getText();
        int ArID2 = parseInt(ArID);
        String ArCPF = txtCPFp.getText();
        //int ArCPF2 = parseInt(ArCPF);

        PreparedStatement psmt;
        String sql = "INSERT INTO PROFESSOR(ID,NOME,DATANASC,CPF,RG,TEL,SEXO,CURSO) VALUES(?,?,?,?,?,?,?,?)";

        try {
            Connection c = null;
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db");

            psmt = c.prepareStatement(sql);
            psmt.setInt(1, ArID2);
            psmt.setString(2, ArNome);
            psmt.setString(3, ArdataNasc);
            psmt.setString(4, ArCPF);
            psmt.setString(5, ArRG);
            psmt.setString(6, ArTell);
            psmt.setString(7, ArSx);
            psmt.setString(8, ArCurso);

            psmt.executeUpdate();
            psmt.close();
            c.close();

            JOptionPane.showMessageDialog(null, "Professor Cadastrado!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    public void Boxinho() {
        Statement smt;
        Connection c = null;
        ResultSet rs = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db"); 
            String SQL = "SELECT NOME FROM CURSO ";
            smt = c.createStatement();
            rs = smt.executeQuery(SQL);
            
            //CBcursoP.removeAllItems();
            while(rs.next()){
            CBcursoP.addItem(rs.getString(1));
            
            }
            CBcursoP.updateUI();
            //JOptionPane.showMessageDialog(null,"Uhuuul");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

    }
    
    
}
