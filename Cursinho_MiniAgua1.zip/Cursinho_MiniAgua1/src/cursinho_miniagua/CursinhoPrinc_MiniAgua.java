package cursinho_miniagua;
/*
 * Sibele Vicente
 */
import javax.swing.JFrame;
import java.sql.*;
import javax.swing.JOptionPane;
//Construção do Banco de dados
public class CursinhoPrinc_MiniAgua {

    public static void main(String[] args) {
        Cursinho_MiniAgua telinha = new Cursinho_MiniAgua();
        Connection c = null;
        Statement stmt = null;
        
        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Não foi possível conectar ao Banco de Dados!");
        }
        JOptionPane.showMessageDialog(null, "Conectado com Banco de Dados!");
        //JOptionPane.showConfirmDialog(null,"Deseja Montar um banco de dados?");
        
        try{
            //Criação das tabelas do BD
        stmt = c.createStatement();
        String sql = "CREATE TABLE IF NOT EXISTS ALUNO" 
                + "(MATRICULA INT PRIMARY KEY NOT NULL,"
                + "TURMA INT,"
                + "NOMEA TEXT ,"
                + "NOMER TEXT ,"
                + "DTNASC TEXT,"
                + "CPF INT2,"
                + "TEL TEXT,"
                + "SEXO TEXT,"
                + "CURSO TEXT,"
                + "TURNO TEXT )";
        stmt.executeUpdate(sql);
        
        String sql2 = "CREATE TABLE IF NOT EXISTS PROFESSOR" 
                + "(ID INT PRIMARY KEY NOT NULL,"
                + "NOME TEXT NOT NULL,"
                + "DATANASC TEXT,"
                + "CPF TEXT,"
                + "RG TEXT,"
                + "TEL TEXT,"
                + "SEXO TEXT,"
                + "CURSO TEXT)";
        stmt.executeUpdate(sql2);
        
        String sql3 = "CREATE TABLE IF NOT EXISTS CURSO"
                +"(ID INT PRIMARY KEY NOT NULL,"
                + "NOME TEXT NOT NULL,"
                + "TURNO TEXT)";
               
        stmt.executeUpdate(sql3);
        
        String sql4 = "CREATE TABLE IF NOT EXISTS INICIACURSO"
                +"(TURMA INT,"
                + "PROFESSOR TEXT,"
                + "CURSO TEXT,"
                + "TURNO TEXT,"
                + "DATA TEXT)";
        stmt.executeUpdate(sql4);
                
        stmt.close();
        c.close();
        } catch (Exception e) {
        
        //JOptionPane.showMessageDialog(null,"Deu Ruim");
        }
    }

}
