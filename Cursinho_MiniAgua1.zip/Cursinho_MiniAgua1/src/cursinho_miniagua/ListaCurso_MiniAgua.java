package cursinho_miniagua;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

/*
 * Sibele Vicente
 */
public class ListaCurso_MiniAgua {
    JFrame telinha7 = new JFrame();
    JPanel botao = new JPanel();
    JPanel ListC = new JPanel();
    //JLabel NomeA = new JLabel("Nome Aluno");
    JButton Ini = new JButton("Iniciar Curso");
    JTable tabela = new JTable();
   public ListaCurso_MiniAgua()  {
        JScrollPane barrinha = new JScrollPane(tabela);
    
        telinha7.setTitle("Lista de Cursos");
        telinha7.setSize(600,450);
        telinha7.setLayout(new GridLayout(2,1));
        telinha7.setResizable(false);
        telinha7.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        telinha7.setLocationRelativeTo(null);
        telinha7.setVisible(true);
        ListC.setLayout(new GridLayout(2,1));  
        
        telinha7.add(ListC);
        ListC.add(barrinha);
        telinha7.add(botao);
        botao.add(Ini);
        CriarTabelaCurso();
   //Ação do botão "Iniciar Curso"
   //Chamando a ação inicia curso 
   class AcaoIniciaCurso implements ActionListener{
        public void actionPerformed(ActionEvent newIc){
          InicioCurso_MiniAgua Ic = new InicioCurso_MiniAgua();
        }
    }
    AcaoIniciaCurso AIC = new AcaoIniciaCurso();
    Ini.addActionListener(AIC);
  
   
    }
    public void CriarTabelaCurso(){
   Connection c = null;
   Statement stmt = null;
   ResultSet rs = null;
   String [] ListarAluno = {"ID", "NOME", "TURNO"};
   
   DefaultTableModel Tmodel = (DefaultTableModel) tabela.getModel();
   
   Tmodel.setColumnIdentifiers(ListarAluno);
   
   String SQL = "SELECT * FROM CURSO";
   
   try{
   Class.forName("org.sqlite.JDBC");
   c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db");
   stmt = c.createStatement();
   rs = stmt.executeQuery(SQL);
   ResultSetMetaData meta = rs.getMetaData();
   int NumColuna = meta.getColumnCount();
   
   while(rs.next()){
   Object[] objs = new Object[NumColuna];
   for(int i = 0;i<NumColuna;i++){
   objs[i] = rs.getObject(i+1);
   }
   Tmodel.addRow(objs);
   }
   tabela.setModel(Tmodel);
   } 
   catch (Exception e){}
   }
}