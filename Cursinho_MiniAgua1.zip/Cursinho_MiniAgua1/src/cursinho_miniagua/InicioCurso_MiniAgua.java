package cursinho_miniagua;

/*
 * Sibele Vicente
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

//Tela de inicinar curso
public class InicioCurso_MiniAgua {

    JFrame telinha9 = new JFrame();
    JPanel vaz = new JPanel();
    JPanel Ini = new JPanel();
    JPanel botao = new JPanel();
    JLabel turma = new JLabel("Turma");
    JLabel Professor = new JLabel("Professor");
    JLabel curso = new JLabel("Curso");
    JLabel turno = new JLabel("Turno");
    JLabel inicio = new JLabel("Inicio");
    JTextField txt_dt = new JTextField("##/##/####");
    JComboBox CBturma = new JComboBox();
    JComboBox CBProf = new JComboBox();
    JComboBox CBturno = new JComboBox();
    JComboBox CBcurso = new JComboBox();
    JButton ok = new JButton("Salvar");
    JButton Lista = new JButton("Cursos Iniciados");

    public InicioCurso_MiniAgua() {
        telinha9.setTitle("Iniciar Curso");
        telinha9.setSize(650, 300);
        telinha9.setLayout(new GridLayout(3, 2));
        telinha9.setResizable(false);
        telinha9.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        telinha9.setLocationRelativeTo(null);
        telinha9.setVisible(true);

        telinha9.add(vaz);
        telinha9.add(Ini);
        Ini.add(turma);
        Ini.add(CBturma);
        CBturma.addItem("");
        Ini.add(Professor);
        Ini.add(CBProf);
        CBProf.addItem("");
        Ini.add(curso);
        Ini.add(CBcurso);
        CBcurso.addItem("");
        Ini.add(turno);
        Ini.add(CBturno);
        CBturno.addItem("");
        CBturno.addItem("Manh�");
        CBturno.addItem("Tarde");
        CBturno.addItem("Noite");
        CBturno.addItem("Integral");
        Ini.add(inicio);
        Ini.add(txt_dt);
        telinha9.add(botao);
        botao.add(ok);
        botao.add(Lista);

        class AcaoArmazena implements ActionListener {

            public void actionPerformed(ActionEvent newLC) {
                if(txt_dt.getText().equals("") || CBturno.getSelectedItem().equals("") || CBturma.getSelectedItem().equals("") || CBcurso.getSelectedItem().equals("") )
                {                               
                JOptionPane.showMessageDialog(null,"Preencha todos os valores");
                }
                else
                {          
                      IniciaCurso();
                        }     
            
            }
        }
        AcaoArmazena AAB = new AcaoArmazena();
        ok.addActionListener(AAB);

        class AcaoListBT implements ActionListener {

            public void actionPerformed(ActionEvent newLC) {
                ListaInicioCurso_MiniAgua LNC = new ListaInicioCurso_MiniAgua();
            }
        }
        AcaoListBT LC = new AcaoListBT();
        Lista.addActionListener(LC);

        BoxCurso();
        BoxTurma();
        BoxProfessor();
       
    }

    void BoxProfessor() {
        Statement smt;
        Connection c = null;
        ResultSet rs = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db");
            String SQL = "SELECT NOME FROM PROFESSOR ";
            smt = c.createStatement();
            rs = smt.executeQuery(SQL);

            //CBcursoP.removeAllItems();
            while (rs.next()) {
                CBProf.addItem(rs.getString(1));

            }
            CBProf.updateUI();
            //JOptionPane.showMessageDialog(null,"Uh4uuu");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

    }

    void BoxTurma() {
        Statement smt;
        Connection c = null;
        ResultSet rs = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db");
            String SQL = "SELECT ID FROM CURSO ";
            smt = c.createStatement();
            rs = smt.executeQuery(SQL);

            //CBcursoP.removeAllItems();
            while (rs.next()) {
                CBturma.addItem(rs.getString(1));

            }
            CBturma.updateUI();
            //JOptionPane.showMessageDialog(null,"Uh6uuu");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

    }

    void BoxCurso() {
        Statement smt;
        Connection c = null;
        ResultSet rs = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db");
            String SQL = "SELECT NOME FROM CURSO ";
            smt = c.createStatement();
            rs = smt.executeQuery(SQL);

            //CBcursoP.removeAllItems();
            while (rs.next()) {
                CBcurso.addItem(rs.getString(1));

            }
            CBcurso.updateUI();
            //JOptionPane.showMessageDialog(null,"Uh5uuu");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

    }

    public void IniciaCurso() {
        
        String ArProf = (String) CBProf.getSelectedItem();
        String Arcurso = (String) CBcurso.getSelectedItem();
        String ArTurno = (String) CBturno.getSelectedItem();
        String ArTurma = (String) CBturma.getSelectedItem();
        String Ardata = txt_dt.getText();
        
        PreparedStatement psmt;
        String sql = "INSERT INTO INICIACURSO(TURMA,PROFESSOR,CURSO,TURNO,DATA) VALUES(?,?,?,?,?)";

        try {
            Connection c = null;
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db");

            psmt = c.prepareStatement(sql);
            
            psmt.setString(1, ArTurma);
            psmt.setString(2, ArProf);
            psmt.setString(3, Arcurso);
            psmt.setString(4, ArTurno);
            psmt.setString(5, Ardata);

            psmt.executeUpdate();
            psmt.close();
            c.close();

            JOptionPane.showMessageDialog(null, "Inicio de Curso Salvo");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}
