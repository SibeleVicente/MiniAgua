package cursinho_miniagua;

/*
 * Sibele Vicente
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Integer.parseInt;
import java.sql.*;
import java.text.SimpleDateFormat;

/*Tela Novo Aluno*/
public class NovoAluno_MiniAgua {

    JFrame telinha3 = new JFrame();
    JPanel vaziozinho = new JPanel();
    JPanel cadastro = new JPanel();
    JPanel cima = new JPanel();
    JPanel baixo = new JPanel();
    JButton salvar = new JButton("Salvar");
    JLabel vazio1 = new JLabel("");
    JLabel vazio2 = new JLabel("");
    JLabel cadAluno = new JLabel("Cadastro de Aluno");
    JLabel nome = new JLabel("Nome do Aluno");
    JTextField txtnomeA = new JTextField(45);
    JLabel nomeResp = new JLabel("Nome do Resp.");
    JTextField txtResp = new JTextField(45);
    JLabel dtNas = new JLabel("Data de Nasc.");
    JTextField txtData = new JTextField("##/##/####");
    JLabel CPF = new JLabel("CPF");
    JTextField txtCPF = new JTextField(11);
    JLabel Tel = new JLabel("Tel");
    JTextField txtTel = new JTextField(9);
    JLabel matricula = new JLabel("Matricula");
    JTextField txtMat = new JTextField(7);
    JLabel sexo = new JLabel("Sexo");
    JComboBox sx = new JComboBox();
    JLabel curso = new JLabel("Curso");
    JComboBox cs = new JComboBox();
    JLabel turma = new JLabel("Turma");
    JComboBox tm = new JComboBox();
    JLabel turno = new JLabel("Turno");
    JComboBox tn = new JComboBox();

    /*Adicionando e tornando visivel os componentes*/
    public NovoAluno_MiniAgua() {

        telinha3.setTitle("Novos Aluno");
        telinha3.setSize(600, 450);
        telinha3.setLayout(new GridLayout(4, 1));
        telinha3.setResizable(false);
        telinha3.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        telinha3.setLocationRelativeTo(null);
        telinha3.setVisible(true);

        telinha3.add(cima);
        cima.add(cadAluno);
        cadAluno.setFont(new Font("Times New Roman", 20, 20));
        telinha3.add(cadastro);
        telinha3.add(vaziozinho);
        telinha3.add(baixo);
        baixo.add(salvar);
        cadastro.add(nome);
        cadastro.add(txtnomeA);
        cadastro.add(nomeResp);
        cadastro.add(txtResp);
        cadastro.add(dtNas);
        cadastro.add(txtData);
        cadastro.add(CPF);
        cadastro.add(txtCPF);
        cadastro.add(Tel);
        cadastro.add(txtTel);
        cadastro.add(matricula);
        cadastro.add(txtMat);
        cadastro.add(sexo);
        cadastro.add(sx);
        sx.addItem("              ");
        sx.addItem("Feminino");
        sx.addItem("Masculino");

        cadastro.add(curso);
        cadastro.add(cs);
        cs.addItem("              ");
        //
        //
        /*As opções seram adicionadas após a criação do BD*/
        cadastro.add(turma);
        cadastro.add(tm);
        tm.addItem("                ");

        //
        //
        //*As opções seram adicionadas após a criação do BD*/
        cadastro.add(turno);
        cadastro.add(tn);
        tn.addItem("              ");
        tn.addItem("Manhã");
        tn.addItem("Tarde");
        tn.addItem("Noite");
        tn.addItem("Integral");

        class AcaoSaveBt implements ActionListener {
            
            public void actionPerformed(ActionEvent newIc) {

                Atualiza();
            }
        }

        AcaoSaveBt ASB = new AcaoSaveBt();
        salvar.addActionListener(ASB);
        BoxinhoCursoAluno();
        BoxinhoTurmaAluno();
    }

    public void Atualiza() {
        
        String ArNome = txtnomeA.getText();
        String ArNomeRes = txtResp.getText();
        String ArdataNasc = txtData.getText();
        //SimpleDateFormat FormatoData = new SimpleDateFormat("dd/MM/yyyy");
        //Date ArdataNasc2 = FormatoData.parse(ArdataNasc);

        String ArTell = txtTel.getText();
        //int ArTell2 = parseInt(ArTell);
        String ArSx = (String) sx.getSelectedItem();
        String ArCurso = (String) cs.getSelectedItem();
        int ArTurma =(int) tm.getSelectedItem();
        String ArTurno = (String) tn.getSelectedItem();
        String ArMat = txtMat.getText();
        int Armat2 = parseInt(ArMat);
        String ArCPF = txtCPF.getText();
        //int ArCPF2 = parseInt(ArCPF);

        PreparedStatement psmt;
        String sql = "INSERT INTO ALUNO(MATRICULA,TURMA,NOMEA,NOMER,DTNASC,CPF,TEL,SEXO,CURSO,TURNO) VALUES(?,?,?,?,?,?,?,?,?,?)";

        try {
            Connection c = null;
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db");

            psmt = c.prepareStatement(sql);
            psmt.setInt(1, Armat2);
            psmt.setInt(2, ArTurma);
            psmt.setString(3,ArNome);
            psmt.setString(4, ArNomeRes);
            psmt.setString(5,ArdataNasc );
            psmt.setString(6, ArCPF );
            psmt.setString(7, ArTell);
            psmt.setString(8, ArSx);
            psmt.setString(9,ArCurso);
            psmt.setString(10, ArTurno);

            psmt.executeUpdate();
            psmt.close();
            c.close();

            JOptionPane.showMessageDialog(null, "Aluno Cadastrado!");
        }   catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void BoxinhoCursoAluno() {
        Statement smt;
        Connection c = null;
        ResultSet rs = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db"); 
            String SQL = "SELECT NOME FROM CURSO ";
            smt = c.createStatement();
            rs = smt.executeQuery(SQL);
            
            //CBcursoP.removeAllItems();
            while(rs.next()){
            cs.addItem(rs.getString(1));
            
            }
            cs.updateUI();
            //JOptionPane.showMessageDialog(null,"Uhuuul");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

    }
     public void BoxinhoTurmaAluno() {
        Statement smt;
        Connection c = null;
        ResultSet rs = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db"); 
            String SQL = "SELECT ID FROM CURSO ";
            smt = c.createStatement();
            rs = smt.executeQuery(SQL);
            
            //CBcursoP.removeAllItems();
            while(rs.next()){
            tm.addItem(rs.getInt(1));
            
            }
            tm.updateUI();
            //JOptionPane.showMessageDialog(null,"Uhuuu");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

    }
}
