package cursinho_miniagua;
/*
 * Sibele Vicente
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//Tela de Botões de cadastros e Listagens
public class MenuCursinho_MiniAgua {
    
  JFrame telinha2 = new JFrame();
  JPanel Painelzinho2 = new JPanel();
  JPanel Painelzinho3 = new JPanel();
  
  JLabel cad = new JLabel("      Cadastros");
  JButton aluno = new JButton("Novo Aluno");
  JButton prof = new JButton("Novo Professor");
  JButton curso = new JButton("Novo Curso");
  JLabel listas = new JLabel("  Lista de dados");
  JButton L_aluno = new JButton("Lista de Alunos");
  JButton L_prof = new JButton("Lista de Prof.");
  JButton L_curso = new JButton("Lista de Curso");
  JLabel vazio1 = new JLabel();
  JLabel vazio2 = new JLabel();
  JLabel vazio3 = new JLabel();
  JLabel vazio4 = new JLabel();
  
    public MenuCursinho_MiniAgua(){
      telinha2.setTitle("Menu Cursinho");
      telinha2.setSize(450,350);
      telinha2.setLayout(new GridLayout(2,2));
      Painelzinho2.setLayout(new GridLayout(2,3,20,20));
      Painelzinho3.setLayout(new GridLayout(2,3,20,20));
      telinha2.setResizable(false);
      telinha2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      telinha2.setVisible(true);
      telinha2.setLocationRelativeTo(null);
      cad.setFont(new Font("Times New Roman",20,20));
      listas.setFont(new Font("Times New Roman",20,20));
      telinha2.add(Painelzinho2);
      telinha2.add(Painelzinho3);
      
      Painelzinho2.add(vazio3);
      Painelzinho2.add(cad);
      Painelzinho2.add(vazio1);
      Painelzinho2.add(aluno);
      Painelzinho2.add(prof);
      Painelzinho2.add(curso);
      Painelzinho3.add(vazio4);
      Painelzinho3.add(listas);
      Painelzinho3.add(vazio2);
      Painelzinho3.add(L_aluno);
      Painelzinho3.add(L_prof);
      Painelzinho3.add(L_curso); 
      
      
     //Ação dos botões da tela
     
        /*Ação do botão Novo Aluno*/
    class AcaoNovoAluno implements ActionListener{
        public void actionPerformed(ActionEvent newA){
         NovoAluno_MiniAgua NvAluno = new NovoAluno_MiniAgua();
                
        }
    }
        /*Ação do botão Novo Prof*/
    class AcaoNovoProf implements ActionListener{
        public void actionPerformed(ActionEvent newP){
         NovoProfessor_MiniAgua NvProf = new NovoProfessor_MiniAgua(); 
             
        }
    }
        /*Ação do botão Novo Curso*/
    class AcaoNovoCurso implements ActionListener{
        public void actionPerformed(ActionEvent newC){
         NovoCurso_MiniAgua NvCurso = new NovoCurso_MiniAgua();
             
        }
    }
        /*Botão de Listagem de Alunos Cadastrados*/
    class AcaoListaAluno implements ActionListener{
        public void actionPerformed(ActionEvent newLA){
         ListaAluno_MiniAgua LAluno = new ListaAluno_MiniAgua();
             
        }
    }
        /*Botão de Listagem de Profs Cadastrados*/
    class AcaoListaProf implements ActionListener{
        public void actionPerformed(ActionEvent newLP){
           ListaProfessor_MiniAgua LProf = new ListaProfessor_MiniAgua(); 
             
        }
    }
        /*Botão de Listagem de Cursos Cadastrados*/
    class AcaoListaCurso implements ActionListener{
        public void actionPerformed(ActionEvent newLC){
            ListaCurso_MiniAgua LCurso = new ListaCurso_MiniAgua();
         
             
        }
    }
       /*Instancioando e chamando a ação*/
    AcaoNovoAluno ANA = new AcaoNovoAluno();
    aluno.addActionListener(ANA);
    AcaoNovoProf ANP = new AcaoNovoProf();
    prof.addActionListener(ANP);
    AcaoNovoCurso ANC = new AcaoNovoCurso();
    curso.addActionListener(ANC);
    AcaoListaAluno ALA = new AcaoListaAluno();
    L_aluno.addActionListener(ALA);
    AcaoListaCurso ALC = new AcaoListaCurso();
    L_curso.addActionListener(ALC);
    AcaoListaProf ALP = new AcaoListaProf();
    L_prof.addActionListener(ALP);
    }
}
