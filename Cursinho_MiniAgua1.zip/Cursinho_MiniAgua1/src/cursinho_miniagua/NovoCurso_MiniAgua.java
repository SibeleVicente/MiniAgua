package cursinho_miniagua;

/*
 * Sibele Vicente
 */
import java.awt.*;
import javax.swing.*;

import controller.NovoCursoController;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/*Tela de cadastro de curso*/
public class NovoCurso_MiniAgua {

    JFrame telinha5 = new JFrame();
    JPanel PainelzinhoA = new JPanel();
    JPanel PainelzinhoC = new JPanel();
    JPanel PainelzinhoB = new JPanel();
    JLabel Ncurso = new JLabel("Cadastrar Curso");
    JLabel nome = new JLabel("Nome");
    JTextField txtNome = new JTextField(40);
    JLabel turno = new JLabel("Turno");
    JComboBox Turno = new JComboBox();
    JLabel Prof = new JLabel("Professor");
    JComboBox prof = new JComboBox();
    JLabel ID = new JLabel("ID");
    JTextField txtID = new JTextField(7);
    JButton btSave = new JButton("Salvar");

    public NovoCurso_MiniAgua() {
        telinha5.setTitle("Novo Curso");
        telinha5.setSize(500, 300);
        telinha5.setLayout(new GridLayout(3, 1));
        telinha5.setResizable(false);
        telinha5.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        telinha5.setLocationRelativeTo(null);
        telinha5.setVisible(true);

        telinha5.add(PainelzinhoA);
        telinha5.add(PainelzinhoC);
        telinha5.add(PainelzinhoB);

        PainelzinhoA.add(Ncurso);
        Ncurso.setFont(new Font("Times New Roman", 20, 20));
        PainelzinhoC.add(nome);
        PainelzinhoC.add(txtNome);
        PainelzinhoC.add(turno);
        PainelzinhoC.add(Turno);
        Turno.addItem("");
        Turno.addItem("Manhã");
        Turno.addItem("Tarde");
        Turno.addItem("Noite");
        Turno.addItem("Integral");
        //PainelzinhoC.add(Prof);
        //PainelzinhoC.add(prof);
        prof.addItem("");
        //
        //
        /*As opções seram adicionadas após a criação do BD*/

        PainelzinhoC.add(ID);
        PainelzinhoC.add(txtID);
        PainelzinhoB.add(btSave);

        class AcaoSaveBt implements ActionListener {
            public void actionPerformed(ActionEvent newIc) {
                if(txtID.getText().equals("") || txtNome.getText().equals("") || Turno.getSelectedItem().equals("") /*|| prof.getSelectedItem().equals("")*/ ){                                
                JOptionPane.showMessageDialog(null, "Preencha todos os campos");
                }
                else{
                CadastraCurso();
                }
            }
        }
        AcaoSaveBt ASB = new AcaoSaveBt();
        btSave.addActionListener(ASB);
        //BoxinhoProfessor();
    }
        public void CadastraCurso(){
        	try {
	            new NovoCursoController().InserirCurso(txtID.getText(), txtNome.getText(), Turno.getSelectedItem().toString());
        		JOptionPane.showMessageDialog(null, "Curso Cadastrado!");
        	}   catch (Exception e) {
        		JOptionPane.showMessageDialog(null, "ERRO ao cadastrar: "+e);
        		e.printStackTrace();
        	}
        }
       /* void BoxinhoProfessor() {
        Statement smt;
        Connection c = null;
        ResultSet rs = null;

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db"); 
            String SQL = "SELECT NOME FROM PROFESSOR ";
            smt = c.createStatement();
            rs = smt.executeQuery(SQL);
            
            //CBcursoP.removeAllItems();
            while(rs.next()){
            prof.addItem(rs.getString(1));
            
            }
            prof.updateUI();
            //JOptionPane.showMessageDialog(null,"Uh1uuu");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }

    }*/
}
