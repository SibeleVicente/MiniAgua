package cursinho_miniagua;
/*
 * @author Sibele
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
public class ListaInicioCurso_MiniAgua {
    JFrame telinha10 = new JFrame();
    JPanel bt = new JPanel();
    JPanel List = new JPanel();
    JTable tabela = new JTable();
    JScrollPane barra = new JScrollPane(tabela);


public ListaInicioCurso_MiniAgua(){
    telinha10.setTitle("Cursos Iniciados");
    telinha10.setSize(600,450);
    telinha10.setLayout(new GridLayout(1,1));
    telinha10.setResizable(false);
    telinha10.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
    telinha10.setLocationRelativeTo(null);
    telinha10.setVisible(true);
    List.setLayout(new GridLayout(2,1));
    
    telinha10.add(List);
   // List.add(tabela);
    List.add(barra);
    //telinha10.add(bt);
    CriarTabelaInicioCurso();

    }
 public void CriarTabelaInicioCurso(){
   Connection c = null;
   Statement stmt = null;
   ResultSet rs = null;
   String [] ListarCursoInicio = {"TURMA", "PROFESSOR", "CURSO", "TURNO", "DATA"};
   
   DefaultTableModel Tmodel = (DefaultTableModel) tabela.getModel();
   
   Tmodel.setColumnIdentifiers(ListarCursoInicio);
   
   String SQL = "SELECT * FROM INICIACURSO";
   
   try{
   Class.forName("org.sqlite.JDBC");
   c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db");
   stmt = c.createStatement();
   rs = stmt.executeQuery(SQL);
   ResultSetMetaData meta = rs.getMetaData();
   int NumColuna = meta.getColumnCount();
   
   while(rs.next()){
   Object[] objs = new Object[NumColuna];
   for(int i = 0;i<NumColuna;i++){
   objs[i] = rs.getObject(i+1);
   }
   Tmodel.addRow(objs);
   }
   tabela.setModel(Tmodel);
   } 
   catch (Exception e){}
   }

}