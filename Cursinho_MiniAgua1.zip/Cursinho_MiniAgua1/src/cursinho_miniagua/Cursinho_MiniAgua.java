package cursinho_miniagua;
/*
 * Sibele Vicente
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.swing.*;


//Nome do projeto
//Só será acessado pelo adm
public class Cursinho_MiniAgua extends JFrame{
        
    JFrame telinha1 = new JFrame();
    JPanel painel = new JPanel();
    JPanel painelbotao = new JPanel();
    
    JLabel nominho = new JLabel("Nome");
    JLabel senha = new JLabel("Senha"); // Senha padrão
    JTextField txtnome = new JTextField("Admin"); //Tem o nome padrão
    JPasswordField txtsenha = new JPasswordField();
    JButton btOk = new JButton("OK");
     
    public Cursinho_MiniAgua(){
    telinha1.setTitle("Login Cursinho");
    telinha1.setSize(300,200);
    telinha1.setLayout(new GridLayout(2,2));
    telinha1.setResizable(false);
    telinha1.setLocationRelativeTo(null);
    telinha1.setVisible(true);
    
    telinha1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    painel.setLayout(new GridLayout(3,3));
    
    telinha1.add(painel);
    painel.add(nominho);
    painel.add(txtnome);
    painel.add(senha);
    painel.add(txtsenha);
    telinha1.add(painelbotao);
    painelbotao.add(btOk);
    
    //Pega a ação do botão
    BtHandler hand = new BtHandler();
    btOk.addActionListener(hand);
    }
    
    //classe da ação
    class BtHandler implements ActionListener{
    
    //Ação do botão
    public void actionPerformed(ActionEvent ae) {
           
           String txtnomeGet = txtnome.getText(); 
           String txtsenhaGet = String.valueOf(txtsenha.getPassword());
           if(txtnomeGet.equals("Admin") && txtsenhaGet.equals("1234")){
              //btOk.setText("Permitido");
             JOptionPane.showMessageDialog(null,"Acesso Permitido!");
             MenuCursinho_MiniAgua menu = new MenuCursinho_MiniAgua();
             telinha1.setVisible(false);
            }
           else
               JOptionPane.showMessageDialog(null,"Acesso Negado!");
        }
    
    }
    
    
} 
   
