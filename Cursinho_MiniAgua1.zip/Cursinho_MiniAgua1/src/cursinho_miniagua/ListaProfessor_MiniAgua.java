package cursinho_miniagua;

/*
 * Sibele Vicente
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

public class ListaProfessor_MiniAgua {

    JFrame telinha8 = new JFrame();
    JPanel titulo = new JPanel();
    JPanel ListP = new JPanel();
    JLabel NomeA = new JLabel("Nome Aluno");
    JTable tabela = new JTable();

    public ListaProfessor_MiniAgua() {

        JScrollPane barrinha = new JScrollPane(tabela);
        telinha8.setTitle("Professores Cadastrados");
        telinha8.setSize(600, 450);
        telinha8.setLayout(new GridLayout(2, 1));
        telinha8.setResizable(false);
        telinha8.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        telinha8.setLocationRelativeTo(null);
        telinha8.setVisible(true);
        ListP.setLayout(new GridLayout(1, 1));

        telinha8.add(ListP);
        ListP.add(barrinha);

        CriarTabelaProfessor();
    }

    public void CriarTabelaProfessor() {
        Connection c = null;
        Statement stmt = null;
        ResultSet rs = null;
        String[] ListarProfessor = {"ID", "NOME", "DATANASC", "CPF", "RG", "TEL", "SEXO", "CURSO"};

        DefaultTableModel Tmodel = (DefaultTableModel) tabela.getModel();

        Tmodel.setColumnIdentifiers(ListarProfessor);

        String SQL = "SELECT * FROM PROFESSOR";

        try {
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db");
            stmt = c.createStatement();
            rs = stmt.executeQuery(SQL);
            ResultSetMetaData meta = rs.getMetaData();
            int NumColuna = meta.getColumnCount();

            while (rs.next()) {
                Object[] objs = new Object[NumColuna];
                for (int i = 0; i < NumColuna; i++) {
                    objs[i] = rs.getObject(i + 1);
                }
                Tmodel.addRow(objs);
            }
            tabela.setModel(Tmodel);
        } catch (Exception e) {
        }
    }
}
