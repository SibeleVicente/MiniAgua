package cursinho_miniagua;
/*
 * Sibele Vicente
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

public class ListaAluno_MiniAgua {
    JFrame telinha6 = new JFrame();
    JPanel titulo = new JPanel();
    JPanel ListA = new JPanel();
    JLabel NomeA = new JLabel("Nome Aluno");
    JTable tabela = new JTable();
   public ListaAluno_MiniAgua()  {
 
        JScrollPane barrinha = new JScrollPane(tabela);
    
        telinha6.setTitle("Alunos Matriculados");
        telinha6.setSize(700,450);
        telinha6.setLayout(new GridLayout(1,1));
        telinha6.setResizable(false);
        telinha6.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        telinha6.setLocationRelativeTo(null);
        telinha6.setVisible(true);
        ListA.setLayout(new GridLayout(1,1));
        telinha6.add(ListA);
        ListA.add(barrinha);
        
       CriarTabela(); 
    }
    
   public void CriarTabela(){
   Connection c = null;
   Statement stmt = null;
   ResultSet rs = null;
   String [] ListarAluno = {"Matricula", "Turma", "NomeA", "NomeR", "DTNASC", "CPF", "TEL", "SEXO", "CURSO", "TURNO"};
   
   DefaultTableModel Tmodel = (DefaultTableModel) tabela.getModel();
   
   Tmodel.setColumnIdentifiers(ListarAluno);
   
   String SQL = "SELECT * FROM ALUNO";
   
   try{
   Class.forName("org.sqlite.JDBC");
   c = DriverManager.getConnection("jdbc:sqlite:Cursinho.db");
   stmt = c.createStatement();
   rs = stmt.executeQuery(SQL);
   ResultSetMetaData meta = rs.getMetaData();
   int NumColuna = meta.getColumnCount();
   
   while(rs.next()){
   Object[] objs = new Object[NumColuna];
   for(int i = 0;i<NumColuna;i++){
   objs[i] = rs.getObject(i+1);
   }
   Tmodel.addRow(objs);
   }
   tabela.setModel(Tmodel);
   } 
   catch (Exception e){}
   }
   
}
