package infra;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class conexao {
	public static final String URL_SQL = "jdbc:sqlite:Cursinho.db";
	public static final String USER = "";
	public static final String SENHA = "";
	
	private static Connection con = null;	//cria um objeto estatico do tipo conex�o
	
	public static Connection getConnection() {
		if (con == null) {	//verifica se a conexao ja esta aberta se n�o ela � aberta
			try {
				Class.forName("org.sqlite.JDBC");	//pega o driver de conexao
				con = DriverManager.getConnection(URL_SQL);		//estabelece a conexao
			}catch(SQLException | ClassNotFoundException erro) {	//trata os erros de sql e do driver
				JOptionPane.showMessageDialog(null, "ERRO NA CONEX�O COM O BANCO! ","Cursinho MiniAgua",JOptionPane.ERROR_MESSAGE);
				System.out.println("ERRO NA CONEXAO: "+erro);
			}
		}
		return con;
	}
}
